// Predicate-generating function. Often useful outside of Underscore.
export default function constant(value) {
  return function() {
    return value;
  };
}
