# bower-webfontloader

This repository is for distribution on `bower`. The source for this module is in
the main [Web Font Loader repository](https://github.com/typekit/webfontloader).

## Install

```shell
bower install --save bower-webfontloader
```
